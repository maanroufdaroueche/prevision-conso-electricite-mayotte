library(tidyverse)
library(forecast)
library(patchwork)
###### IMPORTATION DES DONNÉES ######
Data = read_csv("conso_electricite_mayotte_trimestriel.csv")

# Série temporelle de la consommation corrigée des variations saisonnières
serie_cvs = ts(Data$conso_cvs, start = c(2020, 3), frequency = 4)
# Série temporelle de la consommation brute
serie_brute = ts(Data$conso_brute, start = c(2020, 3), frequency = 4)
# Affichage des deux graphiques
p1 = autoplot(serie_cvs) + ggtitle("Consommation corrigée")
p2 = autoplot(serie_brute) + ggtitle("Consommation brute")
p1 + p2
autoplot(stl(serie_brute, s.window = "periodic"))
###### OBSERVATIONS ######
# La consommation présente une tendance haussière et une saisonnalité marquée,
# ce qui justifie de modéliser la série corrigée des variations saisonnières ».

###### TEST ######
train = window(serie_cvs, end = c(2023, 2))
test  = window(serie_cvs, start = c(2023, 3))

m_tend = tslm(train ~ trend)
m_ets  = ets(train, model = "AAN")

f1 = forecast(m_tend, h = 4)
f2 = forecast(m_ets,  h = 4)

accuracy(f1, test)
accuracy(f2, test)





autoplot(f1) +
  autolayer(test, series = "Consommation réelle") +
  scale_colour_manual(
    values = c("Consommation réelle" = "red")
  ) +
  labs(
    title = "Prévision de la consommation électrique à Mayotte",
    subtitle = "Modèle de tendance linéaire",
    x = "Année",
    y = "Consommation",
    colour = "Série"
  )
###### PRÉVISION FINALE ######
fit = tslm(serie_cvs ~ trend)
fc  = forecast(fit, h = 12)

autoplot(fc) +
  labs(title = "Prévision de la consommation (CVS), 2024T3 à 2027T2",
       x = "Année", y = "Consommation (valeur IEDOM)")

###### SCÉNARIOS ######
base_2023 = sum(window(serie_cvs, start = c(2023, 1), end = c(2023, 4)))
base_2023   # doit afficher 389.4

scen = expand_grid(annee = 2023:2030, taux = c(0.03, 0.05, 0.08)) |>
  mutate(conso = base_2023 * (1 + taux)^(annee - 2023),
         scenario = paste0("+", taux * 100, " % par an"))

ggplot(scen, aes(annee, conso, colour = scenario)) +
  geom_line() +
  labs(title = "Scénarios de croissance de la consommation",
       x = "Année", y = "Consommation annuelle", colour = "Scénario")
